<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `phome_enewsshopdd_add`;");
E_C("CREATE TABLE `phome_enewsshopdd_add` (
  `ddid` int(10) unsigned NOT NULL DEFAULT '0',
  `buycar` mediumtext NOT NULL,
  `bz` text NOT NULL,
  `retext` text NOT NULL,
  PRIMARY KEY (`ddid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");
E_D("replace into `phome_enewsshopdd_add` values('1',0x7c31342c32387c7c327c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('2',0x7c31342c32387c7c317c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('3',0x7c31342c32387c7c327c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('4',0x7c31342c32387c7c317c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('5',0x7c31342c32387c7c337c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('6',0x7c31342c32387c7c317c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('7',0x7c31312c33317c7c317c31307c31307ce5a4a7e59ca3e5bd92e69da5e9a284e5918ae78987efbc88e8a782e79c8be69d83e99990e6bc94e7a4bae4bba5e58f8ae4b88be8bdbde59cb0e59d80e69d83e999902be59ca8e7babfe8b4ade4b9b0e68c89e992aeefbc89217c31342c32387c7c317c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('8',0x7c31342c32387c7c327c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('9',0x7c31342c32387c7c347c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('10',0x7c31342c32387c7c317c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('11',0x7c31342c32387c7c317c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('12',0x7c31312c33317c7c327c31307c31307ce5a4a7e59ca3e5bd92e69da5e9a284e5918ae78987efbc88e8a782e79c8be69d83e99990e6bc94e7a4bae4bba5e58f8ae4b88be8bdbde59cb0e59d80e69d83e999902be59ca8e7babfe8b4ade4b9b0e68c89e992aeefbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('13',0x7c31342c32387c7c327c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('14',0x7c31342c32387c7c347c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('15',0x7c31342c32387c7c327c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('16',0x7c31312c33317c7c327c31307c31307ce5a4a7e59ca3e5bd92e69da5e9a284e5918ae78987efbc88e8a782e79c8be69d83e99990e6bc94e7a4bae4bba5e58f8ae4b88be8bdbde59cb0e59d80e69d83e999902be59ca8e7babfe8b4ade4b9b0e68c89e992aeefbc89217c31342c32387c7c327c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('17',0x7c31342c32387c7c317c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('18',0x7c31342c32387c7c317c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('19',0x7c31342c32387c7c317c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('20',0x7c31342c32387c7c317c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('21',0x7c31342c32387c7c327c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc89217c31312c33317c7c317c31307c31307ce5a4a7e59ca3e5bd92e69da5e9a284e5918ae78987efbc88e8a782e79c8be69d83e99990e6bc94e7a4bae4bba5e58f8ae4b88be8bdbde59cb0e59d80e69d83e999902be59ca8e7babfe8b4ade4b9b0e68c89e992aeefbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('22',0x7c31342c32387c7c317c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('23',0x7c31342c32387c7c317c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('24',0x7c31342c32387c7c317c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('25',0x7c31342c32387c7c327c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('26',0x7c31342c32387c7c327c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('27',0x7c31342c32387c7c317c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('28',0x7c31342c32387c7c327c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc89217c31312c33317c7c317c31307c31307ce5a4a7e59ca3e5bd92e69da5e9a284e5918ae78987efbc88e8a782e79c8be69d83e99990e6bc94e7a4bae4bba5e58f8ae4b88be8bdbde59cb0e59d80e69d83e999902be59ca8e7babfe8b4ade4b9b0e68c89e992aeefbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('29',0x7c31342c32387c7c317c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('30',0x7c31342c32387c7c317c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('31',0x7c31342c32387c7c327c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('32',0x7c31342c32387c7c317c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('33',0x7c31312c33317c7c327c31307c31307ce5a4a7e59ca3e5bd92e69da5e9a284e5918ae78987efbc88e8a782e79c8be69d83e99990e6bc94e7a4bae4bba5e58f8ae4b88be8bdbde59cb0e59d80e69d83e999902be59ca8e7babfe8b4ade4b9b0e68c89e992aeefbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('34',0x7c31342c32387c7c317c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('35',0x7c31342c32387c7c327c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('36',0x7c31342c32387c7c317c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('37',0x7c31342c32387c7c317c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('38',0x7c31342c32387c7c317c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('39',0x7c31342c32387c7c347c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('40',0x7c31342c32387c7c327c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('41',0x7c31342c32387c7c337c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('42',0x7c31342c32387c7c317c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('43',0x7c31342c32387c7c317c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");
E_D("replace into `phome_enewsshopdd_add` values('44',0x7c31342c32387c7c317c3139397c3139397ce8b4ade4b9b0e69cace5b89de59bbd434d53e6a8a1e69dbfe695b4e7ab99e6ba90e7a081efbc88e6b58be8af95e7ab99e58685e8b4ade4b9b0efbc8921,'','');");

@include("../../inc/footer.php");
?>