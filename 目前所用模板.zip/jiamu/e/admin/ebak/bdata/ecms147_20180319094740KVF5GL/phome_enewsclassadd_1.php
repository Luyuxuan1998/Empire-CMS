<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `phome_enewsclassadd`;");
E_C("CREATE TABLE `phome_enewsclassadd` (
  `classid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `classtext` mediumtext NOT NULL,
  `ttids` text NOT NULL,
  `eclasspagetext` mediumtext NOT NULL,
  PRIMARY KEY (`classid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");
E_D("replace into `phome_enewsclassadd` values('1','','','');");
E_D("replace into `phome_enewsclassadd` values('2','','','');");
E_D("replace into `phome_enewsclassadd` values('3','','','');");
E_D("replace into `phome_enewsclassadd` values('4','','','');");
E_D("replace into `phome_enewsclassadd` values('5','','','');");
E_D("replace into `phome_enewsclassadd` values('6','','','');");
E_D("replace into `phome_enewsclassadd` values('7','','','');");
E_D("replace into `phome_enewsclassadd` values('8','','','');");
E_D("replace into `phome_enewsclassadd` values('9','','','');");
E_D("replace into `phome_enewsclassadd` values('10','','','');");
E_D("replace into `phome_enewsclassadd` values('11','','','');");
E_D("replace into `phome_enewsclassadd` values('12','','','');");
E_D("replace into `phome_enewsclassadd` values('13','','','');");
E_D("replace into `phome_enewsclassadd` values('14','','','');");
E_D("replace into `phome_enewsclassadd` values('15','','','');");
E_D("replace into `phome_enewsclassadd` values('16','','',0xe694afe68c8148544d4ce6a8a1e5bc8fefbc8ce694afe68c81e59bbee69687efbc81e5908ee58fb02d2de6a08fe79bae2d2de6a08fe79baee7aea1e790862d2de7bbbce59088e6a08fe79bae2d2de4bfaee694b92d2de58d95e9a1b5e58685e5aeb920266e6273703be9878ce99da2e4bfaee694b9efbc81);");
E_D("replace into `phome_enewsclassadd` values('17','','',0xe694afe68c8148544d4ce6a8a1e5bc8fefbc8ce694afe68c81e59bbee69687efbc81e5908ee58fb02d2de6a08fe79bae2d2de6a08fe79baee7aea1e790862d2de585b3e4ba8ee68891e4bbac2d2de4bfaee694b92d2de58d95e9a1b5e58685e5aeb920266e6273703be9878ce99da2e4bfaee694b9efbc81);");
E_D("replace into `phome_enewsclassadd` values('18','','','');");
E_D("replace into `phome_enewsclassadd` values('19','','',0xe694afe68c8148544d4ce6a8a1e5bc8fefbc8ce694afe68c81e59bbee69687efbc81e5908ee58fb02d2de6a08fe79bae2d2de6a08fe79baee7aea1e790862d2de5858de8b4a3e5a3b0e6988e2d2de4bfaee694b92d2de58d95e9a1b5e58685e5aeb920266e6273703be9878ce99da2e4bfaee694b9efbc81);");
E_D("replace into `phome_enewsclassadd` values('20','','',0xe694afe68c8148544d4ce6a8a1e5bc8fefbc8ce694afe68c81e59bbee69687efbc81e5908ee58fb02d2de6a08fe79bae2d2de6a08fe79baee7aea1e790862d2de5858de8b4a3e5a3b0e6988e2d2de4bfaee694b92d2de58d95e9a1b5e58685e5aeb920266e6273703be9878ce99da2e4bfaee694b9efbc81);");
E_D("replace into `phome_enewsclassadd` values('21','','','');");
E_D("replace into `phome_enewsclassadd` values('22',0xe694afe68c8148544d4ce6a8a1e5bc8fefbc8ce694afe68c81e59bbee69687efbc81e5908ee58fb02d2de6a08fe79bae2d2de6a08fe79baee7aea1e790862d2de7bbbce59088e6a08fe79bae2d2de4bfaee694b92d2de6a8a1e69dbfe98089e9a1b92d2de9a1b5e99da2e58685e5aeb92020e9878ce99da2e4bfaee694b9efbc81,'','');");
E_D("replace into `phome_enewsclassadd` values('23','','','');");

@include("../../inc/footer.php");
?>